<div id="footer">
<h1>FOOTER</h1>
</div>
</div>
</body>
</html>